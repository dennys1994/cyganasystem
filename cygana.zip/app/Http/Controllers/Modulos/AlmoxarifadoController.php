<?php

namespace App\Http\Controllers\Modulos;

use App\Http\Controllers\Controller;
use App\Models\Modulos\Patrimonio;
use App\Models\Modulos\GrupoPatrimonio;
use App\Models\Modulos\RetiradaPatrimonio;
use App\Models\Modulos\Patrimonio\SetorPat;
use App\Models\Modulos\Patrimonio\FuncaoPat;
use App\Models\Modulos\Patrimonio\TamanhoPat;

use Illuminate\Http\Request;

class AlmoxarifadoController extends Controller
{
    // Setor
     // Exibir todos os setores
    public function index_setor()
    {
        $setores = SetorPat::all(); // Obtém todos os setores
        return view('Modulos.Almoxarifado.Setor.index', compact('setores')); // Retorna a view com a lista
    }

    // Mostrar o formulário para criar um novo setor
    public function create_setor()
    {
        return view('Modulos.Almoxarifado.Setor.create'); // Retorna a view de criação
    }

    // Armazenar um novo setor
    public function store_setor(Request $request)
    {
        $request->validate([
            'nome' => 'required|unique:setor_pats|max:100', // Validação para o nome único
        ]);
        SetorPat::create([
            'nome' => $request->nome, // Armazena o nome do setor
        ]);
        return redirect()->route('setores.index')->with('success', 'Setor criado com sucesso!');
    }

    // Mostrar o formulário para editar um setor
    public function edit_setor(SetorPat $setor)
    {
        return view('Modulos.Almoxarifado.Setor.edit', compact('setor')); // Retorna a view de edição com os dados do setor
    }

    // Atualizar um setor existente
    public function update_setor(Request $request, SetorPat $setor)
    {
        $request->validate([
            'nome' => 'required|max:100|unique:setor_pats,nome,' . $setor->id, // Validação com exceção do próprio setor
        ]);
        $setor->update([
            'nome' => $request->nome, // Atualiza o nome do setor
        ]);
        return redirect()->route('setores.index')->with('success', 'Setor atualizado com sucesso!');
    }

    // Deletar um setor
    public function destroy_setor(SetorPat $setor)
    {
        $setor->delete(); // Deleta o setor
        return redirect()->route('setores.index')->with('success', 'Setor excluído com sucesso!');
    }
    //End Setor
    /*------------//----------------//------------------------------------------//------------------------------------------------//--------------------------------------*/
    //Função
    public function index_funcao()
    {
        $funcaoPats = FuncaoPat::all();
        return view('Modulos.Almoxarifado.Funcao.index', compact('funcaoPats'));
    }

    public function create_funcao()
    {
        return view('Modulos.Almoxarifado.Funcao.create');
    }

    public function store_funcao(Request $request)
    {
        $request->validate([
            'nome' => 'required|unique:funcao_pats|max:100',
        ]);

        FuncaoPat::create($request->all());

        return redirect()->route('funcao.index')->with('success', 'Função criada com sucesso.');
    }

    public function edit_funcao($id)
    {
        $funcaoPat = FuncaoPat::findOrFail($id);
        return view('Modulos.Almoxarifado.Funcao.edit', compact('funcaoPat'));
    }

    public function update_funcao(Request $request, $id)
    {
        // $funcao deve conter o identificador passado na URL
        $funcaoModel = FuncaoPat::findOrFail($id);

        // Atualize os dados conforme necessário
        $funcaoModel->update($request->all());

        return redirect()->route('funcao.index')->with('success', 'Função atualizada com sucesso.');
    }

    public function destroy_funcao($id)
    {
        $funcaoPat = FuncaoPat::findOrFail($id);
        $funcaoPat->delete();

        return redirect()->route('funcao.index')->with('success', 'Função excluída com sucesso.');
    }
    //end função
    /*------------//----------------//------------------------------------------//------------------------------------------------//--------------------------------------*/

    public function index_tamanho()
    {
        $tamanhoPats = TamanhoPat::all();
        return view('Modulos.Almoxarifado.Tamanho.index', compact('tamanhoPats'));
    }

    public function create_tamanho()
    {
        return view('Modulos.Almoxarifado.Tamanho.create');
    }

    public function store_tamanho(Request $request)
    {
        $request->validate([
            'tamanho' => 'required|max:50',
        ]);

        TamanhoPat::create($request->all());

        return redirect()->route('tamanho.index')->with('success', 'Tamanho cadastrado com sucesso.');
    }

    public function edit_tamanho($id)
    {
        $tamanhoPat = TamanhoPat::findOrFail($id);
        return view('Modulos.Almoxarifado.Tamanho.edit', compact('tamanhoPat'));
    }

    public function update_tamanho(Request $request, $id)
    {   
        // $funcao deve conter o identificador passado na URL
        $tamanhoPat = TamanhoPat::findOrFail($id);

        // Atualize os dados conforme necessário
        $tamanhoPat->update($request->all());

        return redirect()->route('tamanho.index')->with('success', 'Tamanho atualizado com sucesso.');
    }

    public function destroy_tamanho($id)
    {
        $tamanhoPat = TamanhoPat::findOrFail($id);

        $tamanhoPat->delete();

        return redirect()->route('tamanho.index')->with('success', 'Tamanho excluído com sucesso.');
    }

    /*------------//----------------//------------------------------------------//------------------------------------------------//--------------------------------------*/

    // Exibir todos os itens do almoxarifado
    public function index()
    {
        $patrimonios = Patrimonio::with(['setorPat', 'funcaoPat', 'tamanhoPat'])->get();
        return view('Modulos.Almoxarifado.index', compact('patrimonios'));
    }

    public function create()
    {
        $setores = SetorPat::all();
        $funcoes = FuncaoPat::all();
        $tamanhos = TamanhoPat::all();
        return view('Modulos.Almoxarifado.create', compact('setores', 'funcoes', 'tamanhos'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'nome_completo' => 'required|max:255',
            'series' => 'required|integer|min:1',
            'setor_pat_id' => 'nullable|exists:setor_pats,id',
            'funcao_pat_id' => 'nullable|exists:funcao_pats,id',
            'tamanho_pat_id' => 'nullable|exists:tamanho_pats,id',
            'tipo_pat' => 'required|in:1,2',
            'nova_funcao' => 'nullable|string|max:100',
            'novo_tamanho' => 'nullable|string|max:50',
        ]);

        // Verificar se o usuário digitou um novo valor para a função
        if ($request->nova_funcao) {
            $funcao = FuncaoPat::firstOrCreate(['nome' => $request->nova_funcao]);
            $funcaoId = $funcao->id;
        } else {
            $funcaoId = $request->funcao_pat_id;
        }

        // Verificar se o usuário digitou um novo valor para o tamanho
        if ($request->novo_tamanho) {
            $tamanho = TamanhoPat::firstOrCreate(['tamanho' => $request->novo_tamanho]);
            $tamanhoId = $tamanho->id;
        } else {
            $tamanhoId = $request->tamanho_pat_id;
        }

        // Garantir que o setor e a função tenham 2 dígitos
        $setorId = str_pad($request->setor_pat_id, 2, '0', STR_PAD_LEFT);
        $funcaoId = str_pad($funcaoId, 2, '0', STR_PAD_LEFT);

        $tamanho = TamanhoPat::findOrFail($tamanhoId);
        $tamanhoNome = $tamanho->tamanho;
        preg_match_all('/\d+/', $tamanhoNome, $matches);
        $tamanhoCodigo = isset($matches[0]) ? str_pad(implode('', array_slice($matches[0], 0, 3)), 3, '0', STR_PAD_LEFT) : '000';        

        // Gerar o nome_abv com 4 dígitos a partir do id
        $nomeAbv = str_pad(Patrimonio::max('id') + 1, 4, '0', STR_PAD_LEFT);

        // Gerar o código base para o patrimônio
        $codigoBase = $nomeAbv . '-' . $setorId . '-'. $request->tipo_pat . '-' . $funcaoId . '-' . $tamanhoCodigo;

        // Criar o array para as séries
        $seriesArray = [];

        // Gerar os códigos das séries e estados
        for ($i = 1; $i <= $request->series; $i++) {
            $codigo = $codigoBase . '-' . str_pad($i, 2, '0', STR_PAD_LEFT);
            $seriesArray[] = ['codigo' => $codigo, 'estado' => 'disponível'];
        }

        // Criar o patrimônio
        Patrimonio::create([
            'codigo' => $codigoBase,
            'nome_abv' => $nomeAbv,
            'nome_completo' => $request->nome_completo,
            'series' => json_encode($seriesArray),
            'setor_pat_id' => $request->setor_pat_id,
            'funcao_pat_id' => $funcaoId,
            'tamanho_pat_id' => $tamanhoId,
            'tipo_pat' => $request->tipo_pat,
        ]);

        return redirect()->route('almoxarifado.index')->with('success', 'Patrimônio criado com sucesso.');
    }


    public function edit($id)
    {
        $patrimonio = Patrimonio::findOrFail($id);
        $setores = SetorPat::all();
        $funcoes = FuncaoPat::all();
        $tamanhos = TamanhoPat::all();
        return view('Modulos.Almoxarifado.edit', compact('patrimonio', 'setores', 'funcoes', 'tamanhos'));
    }

    public function update(Request $request, $id)
    {
        // Encontra o patrimônio pelo id fornecido
        $patrimonio = Patrimonio::findOrFail($id);
    
        // Validação dos dados
        $request->validate([
            'nome_completo' => 'required|max:255',
            'series' => 'required|integer|min:1',
            'setor_pat_id' => 'nullable|exists:setor_pats,id',
            'funcao_pat_id' => 'nullable|exists:funcao_pats,id',
            'tamanho_pat_id' => 'nullable|exists:tamanho_pats,id',
        ]);
    
        // Garantir que o setor e a função tenham 2 dígitos
        $setorId = str_pad($request->setor_pat_id, 2, '0', STR_PAD_LEFT);
        $funcaoId = str_pad($request->funcao_pat_id, 2, '0', STR_PAD_LEFT);
    
        // Extrair os 3 primeiros números do nome do tamanho, completando com zero se necessário
        $tamanho = TamanhoPat::findOrFail($request->tamanho_pat_id);
        $tamanhoNome = $tamanho->tamanho;
        preg_match_all('/\d+/', $tamanhoNome, $matches);
        $tamanhoCodigo = isset($matches[0]) ? str_pad(implode('', array_slice($matches[0], 0, 3)), 3, '0', STR_PAD_LEFT) : '000';
    
        // O nome_abv já existe no banco de dados, então não alteramos o valor para manter o id correto
        // Gerar o código base para o patrimônio (com 2 dígitos para setor, função e o código de tamanho)
        $codigoBase = $patrimonio->nome_abv . '-' . $setorId . '-' . $funcaoId . '-' . $tamanhoCodigo;
    
        // Criar o array para as séries
        $seriesArray = [];
    
        // Gerar os códigos das séries e estados
        for ($i = 1; $i <= $request->series; $i++) {
            // Gerar o código da série para a série atual
            $codigo = $codigoBase . '-' . str_pad($i, 2, '0', STR_PAD_LEFT);  // Exemplo: nome_abv-1-2-3-01
    
            // Adicionar o código e o estado da série ao array (estado pode ser 'disponível' ou 'indisponível')
            $seriesArray[] = [
                'codigo' => $codigo,
                'estado' => 'disponível',  // Ou 'indisponível', dependendo da lógica do seu sistema
            ];
        }
    
        // Atualizar o patrimônio
        $patrimonio->update([
            'codigo' => $codigoBase,  // Código base do patrimônio
            'nome_abv' => $patrimonio->nome_abv,  // Manter o nome_abv já existente
            'nome_completo' => $request->nome_completo,
            'series' => json_encode($seriesArray),  // Atualizar as séries como JSON
            'setor_pat_id' => $request->setor_pat_id,
            'funcao_pat_id' => $request->funcao_pat_id,
            'tamanho_pat_id' => $request->tamanho_pat_id,
        ]);
    
        // Redireciona com mensagem de sucesso
        return redirect()->route('almoxarifado.index')->with('success', 'Patrimônio atualizado com sucesso.');
    }
    


    public function destroy($id)
    {
        $patrimonio = Patrimonio::findOrFail($id);

        $patrimonio->delete();
        return redirect()->route('almoxarifado.index')->with('success', 'Patrimônio excluído com sucesso.');
    }

    public function generateBarcode($id)
    {
        $patrimonio = Patrimonio::find($id);
        $series = json_decode($patrimonio->series);

        return view('Modulos.Almoxarifado.barcode', [
            'series' => $series,
            'nome_completo' => $patrimonio->nome_completo // Passando o nome completo
        ]);
    }

}
