<?php

namespace App\Models\Modulos;

use Illuminate\Database\Eloquent\Model;
use App\Models\User;

class RetiradaPatrimonio extends Model
{
    protected $fillable = ['grupo_patrimonio_id', 'patrimonio_id', 'series_retiradas', 'data_retirada', 'responsavel_id', 'tecnico_responsavel_id'];

    // Relacionamento com Patrimonio
    public function patrimonio()
    {
        return $this->belongsTo(Patrimonio::class);
    }

    // Relacionamento com GrupoPatrimonio
    public function grupoPatrimonio()
    {
        return $this->belongsTo(GrupoPatrimonio::class);
    }

    // Relacionamento com o responsável pelo cadastro da retirada
    public function responsavel()
    {
        return $this->belongsTo(User::class, 'responsavel_id');
    }

    // Relacionamento com o técnico responsável pela retirada
    public function tecnicoResponsavel()
    {
        return $this->belongsTo(User::class, 'tecnico_responsavel_id');
    }
}
