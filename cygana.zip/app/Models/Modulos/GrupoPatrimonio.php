<?php

namespace App\Models\Modulos;

use Illuminate\Database\Eloquent\Model;

class GrupoPatrimonio extends Model
{
    protected $fillable = ['nome', 'patrimonios'];

    protected $casts = [
        'patrimonios' => 'array',  // Para garantir que os patrimônios sejam tratados como array de IDs
    ];

    // Relacionamento com a tabela Patrimonio
    public function patrimônios()
    {
        return $this->belongsToMany(Patrimonio::class, 'grupo_patrimonio_patrimonio');
    }

    // Relacionamento com RetiradaPatrimonio
    public function retiradas()
    {
        return $this->hasMany(RetiradaPatrimonio::class);
    }
}
