<?php

namespace App\Models\Modulos\Patrimonio;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FuncaoPat extends Model
{
    use HasFactory;

    protected $fillable = ['nome'];
}
